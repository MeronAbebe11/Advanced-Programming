#!/usr/bin/perl
use strict;
use warnings;
use Bio::DB::GenBank;

# Exercise 9: GenBank Retrieval

# Create a GenBank object
my $gb = Bio::DB::GenBank->new;

# Retrieve sequence by accession
my $seq = $gb->get_Seq_by_acc("NM_174738");

# Print details
print "Accession: ", $seq->accession_number, "\n";
print "Description: ", $seq->desc, "\n";
print "Length: ", $seq->length, "\n";
