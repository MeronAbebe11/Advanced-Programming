#!/usr/bin/perl
use strict;
use warnings;

# Exercise 6: Restriction Enzyme Finder

my $seq = "ATCGAATTCGGGGAATTCATC";
my $enzyme = "GAATTC";

# Search for all positions of EcoRI sites
my $pos = 0;
while (($pos = index($seq, $enzyme, $pos)) != -1) {
    # Add 1 because Perl uses 0-based indexing
    my $position = $pos + 1;
    print "EcoRI found at position $position\n";
    $pos++; # Move forward to continue searching
}
