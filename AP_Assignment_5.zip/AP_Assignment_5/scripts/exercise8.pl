#!/usr/bin/perl
use strict;
use warnings;
use Bio::SeqIO;

# Exercise 8: BioPerl FASTA Parsing

# Input FASTA file
my $file = "../data/genes.fasta";

# Create SeqIO object
my $seqio = Bio::SeqIO->new(-file => $file, -format => 'fasta');

# Loop through sequences
while (my $seq = $seqio->next_seq) {
    my $id = $seq->id;
    my $length = $seq->length;
    my $first10 = $seq->subseq(1,10);

    print "ID: $id\n";
    print "Length: $length\n";
    print "First 10 bp: $first10\n";
    print "\n";
}
