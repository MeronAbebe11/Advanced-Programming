#!/usr/bin/perl
use strict;
use warnings;

# Exercise 4: DNA Sequence Statistics

my $seq = "ATGCGCGATATCGCGAT";

# Sequence length
my $length = length($seq);

# Count G bases
my $g_count = ($seq =~ tr/G/G/);

# Count C bases
my $c_count = ($seq =~ tr/C/C/);

# GC total
my $gc_count = $g_count + $c_count;

# GC percentage
my $gc_percent = ($gc_count / $length) * 100;

# Print results
print "Length: $length\n";
print "GC Count: $gc_count\n";
print "GC%: $gc_percent\n";
