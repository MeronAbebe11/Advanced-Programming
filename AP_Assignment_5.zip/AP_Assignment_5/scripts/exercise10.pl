#!/usr/bin/perl
use strict;
use warnings;
use Bio::SearchIO;

# Exercise 10: BLAST Result Parsing

# Input BLAST output file
my $file = "../data/blast.out";

# Create SearchIO object
my $searchio = Bio::SearchIO->new(-file => $file, -format => 'blast');

# Loop through results
while (my $result = $searchio->next_result) {
    while (my $hit = $result->next_hit) {
        while (my $hsp = $hit->next_hsp) {
            print $hit->name, "\t", $hit->significance, "\t", $hsp->percent_identity, "\n";
        }
    }
}
