#!/usr/bin/perl
use strict;
use warnings;

# Exercise 3: Hashes

# Create a hash to store gene lengths
my %gene_lengths = (
    "EDN3"  => 2156,
    "PDE5A" => 3245,
    "DNAH7" => 8540,
    "IKBKG" => 4021
);

# Print one gene length
print "EDN3 length = $gene_lengths{'EDN3'}\n";

# Optional: loop through all genes
foreach my $gene (keys %gene_lengths) {
    print "$gene length = $gene_lengths{$gene}\n";
}
