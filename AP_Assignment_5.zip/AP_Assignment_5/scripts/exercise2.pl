#!/usr/bin/perl
use strict;
use warnings;

# Exercise 2: Arrays and Loops

# Create an array of gene names
my @genes = ("EDN3", "PDE5A", "DNAH7", "IKBKG");

# Loop through the array and print each gene
foreach my $gene (@genes) {
    print "$gene\n";
}
