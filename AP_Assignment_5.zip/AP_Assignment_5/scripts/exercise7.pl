#!/usr/bin/perl
use strict;
use warnings;

# Exercise 7: FASTA File Reader

my $file = "../data/genes.fasta";
open(my $fh, "<", $file) or die "Cannot open $file: $!";

my $id = "";
my $seq = "";

while (my $line = <$fh>) {
    chomp $line;
    if ($line =~ /^>(\S+)/) {
        # If we already have a sequence, print its length
        if ($seq ne "") {
            my $length = length($seq);
            print "$id $length\n";
            $seq = "";
        }
        $id = $1; # Capture sequence ID
    } else {
        $seq .= $line; # Append sequence lines
    }
}

# Print last sequence
if ($seq ne "") {
    my $length = length($seq);
    print "$id $length\n";
}

close($fh);

