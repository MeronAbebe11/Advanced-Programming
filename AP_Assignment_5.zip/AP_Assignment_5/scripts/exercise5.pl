#!/usr/bin/perl
use strict;
use warnings;

# Exercise 5: Reverse Complement

my $seq = "ATGCCGAAT";

# Complement the sequence
$seq =~ tr/ACGT/TGCA/;

# Reverse the complemented sequence
my $rev_comp = reverse($seq);

# Print result
print "Reverse complement: $rev_comp\n";
