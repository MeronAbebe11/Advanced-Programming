# Example sequences
seq1 <- "GATTACA"
seq2 <- "GCATGCU"

# Scoring scheme
match <- 1
mismatch <- -1
gap <- -2

# Matrix initialization
n <- nchar(seq1)
m <- nchar(seq2)
score_matrix <- matrix(0, n+1, m+1)

# Initialize first row/column
for (i in 1:(n+1)) score_matrix[i,1] <- (i-1)*gap
for (j in 1:(m+1)) score_matrix[1,j] <- (j-1)*gap

# Fill matrix
for (i in 2:(n+1)) {
  for (j in 2:(m+1)) {
    char1 <- substr(seq1, i-1, i-1)
    char2 <- substr(seq2, j-1, j-1)
    score_diag <- score_matrix[i-1,j-1] + ifelse(char1==char2, match, mismatch)
    score_up <- score_matrix[i-1,j] + gap
    score_left <- score_matrix[i,j-1] + gap
    score_matrix[i,j] <- max(score_diag, score_up, score_left)
  }
}

print(score_matrix)

# Traceback procedure
aligned_seq1 <- ""
aligned_seq2 <- ""

i <- n+1
j <- m+1

while (i > 1 || j > 1) {
  if (i > 1 && j > 1) {
    char1 <- substr(seq1, i-1, i-1)
    char2 <- substr(seq2, j-1, j-1)
    score_current <- score_matrix[i,j]
    score_diag <- score_matrix[i-1,j-1] + ifelse(char1==char2, match, mismatch)
    
    if (score_current == score_diag) {
      aligned_seq1 <- paste0(char1, aligned_seq1)
      aligned_seq2 <- paste0(char2, aligned_seq2)
      i <- i-1; j <- j-1
      next
    }
  }
  
  if (i > 1 && score_matrix[i,j] == score_matrix[i-1,j] + gap) {
    aligned_seq1 <- paste0(substr(seq1, i-1, i-1), aligned_seq1)
    aligned_seq2 <- paste0("-", aligned_seq2)
    i <- i-1
  } else {
    aligned_seq1 <- paste0("-", aligned_seq1)
    aligned_seq2 <- paste0(substr(seq2, j-1, j-1), aligned_seq2)
    j <- j-1
  }
}

cat("Aligned Sequence 1:", aligned_seq1, "\n")
cat("Aligned Sequence 2:", aligned_seq2, "\n")

# Highlight matches and mismatches
match_line <- ""
for (k in 1:nchar(aligned_seq1)) {
  if (substr(aligned_seq1, k, k) == substr(aligned_seq2, k, k)) {
    match_line <- paste0(match_line, "|")
  } else {
    match_line <- paste0(match_line, " ")
  }
}

cat(aligned_seq1, "\n")
cat(match_line, "\n")
cat(aligned_seq2, "\n")


library(ggplot2)
library(reshape2)

score_df <- melt(score_matrix)
ggplot(score_df, aes(Var2, Var1, fill=value)) +
  geom_tile(color="white") +
  scale_fill_gradient(low="lightblue", high="darkblue") +
  labs(title="Global Alignment Scoring Matrix",
       x="Sequence 2", y="Sequence 1") +
  theme_minimal()
ggplot(score_df, aes(Var2, Var1, fill=value)) +
  geom_tile(color="white") +
  scale_fill_gradient(low="#cce5ff", high="#003366") +
  labs(title="Needleman–Wunsch Scoring Matrix",
       x="Sequence 2 (GCATGCU)",
       y="Sequence 1 (GATTACA)",
       fill="Score") +
  theme_minimal(base_size = 14)

seq1

library(Biostrings)
seqs2 <- readDNAStringSet("MT-ND2.fasta")
seq2 <- as.character(seqs2[[1]])


library(Biostrings)

# Load ND1 and ND2 sequences
seqs1 <- readDNAStringSet("MT-ND1.fasta")
seqs2 <- readDNAStringSet("MT-ND2.fasta")

seq1 <- as.character(seqs1[[1]])
seq2 <- as.character(seqs2[[1]])


aligned_seq <- pairwiseAlignment(
  DNAString(seq1),
  DNAString(seq2),
  substitutionMatrix = nucleotideSubstitutionMatrix(match = 1, mismatch = -1),
  gapOpening = -2,
  gapExtension = -1
)

aligned_seq

writePairwiseAlignments(aligned_seq, file = "ND1_ND2_alignment.txt")

pattern(aligned_seq)
subject(aligned_seq)

matches <- nmatch(aligned_seq)
total <- nchar(pattern(aligned_seq))
similarity <- (matches / total) * 100
similarity





library(ggplot2)
library(Biostrings)

# Compute pairwise alignment matrix
mat <- pairwiseAlignment(DNAString(seq1), DNAString(seq2))
score <- score(mat)

# Create a simple heatmap
ggplot(data.frame(x = 1, y = 1, score = score)) +
  geom_tile(aes(x, y, fill = score)) +
  scale_fill_gradient(low = "red", high = "green") +
  labs(title = "ND1 vs ND2 Alignment Score Heatmap",
       fill = "Score")




library(Biostrings)

seq1 <- readDNAStringSet("MT-ND1.fasta")[[1]]
seq2 <- readDNAStringSet("MT-ND2.fasta")[[1]]


seq1_vec <- strsplit(as.character(seq1), "")[[1]]
seq2_vec <- strsplit(as.character(seq2), "")[[1]]


library(seqinr)
dotPlot(seq1_vec[1:500], seq2_vec[1:500], main = "ND1 vs ND2 Dot Plot", col = "blue")
dotPlot(seq1_vec, seq2_vec, wsize = 5, nmatch = 4, main = "ND1 vs ND2 Filtered Dot Plot", col = "darkgreen")

library(seqinr)
dotPlot(seq1_vec, seq2_vec, main = "ND1 vs ND2 Dot Plot", col = "blue")



# Batch Alignment Visualization
# Load required libraries
library(ggplot2)
library(gridExtra)
library(DECIPHER)
library(Biostrings)

# Step 1: Load ND FASTA files
files <- list.files(pattern = "ND[1-6]\\.fasta$")
seqs <- lapply(files, readDNAStringSet)

# Step 2: Generate all pairwise combinations
pairs <- combn(seqs, 2, simplify = FALSE)

# Step 3: Perform alignments for each pair
results <- lapply(pairs, function(pair) {
  AlignSeqs(do.call(c, pair))
})

# Step 4: Create scoring matrices for visualization
score_matrices <- lapply(results, function(aln) {
  mat <- consensusMatrix(aln)
  df <- as.data.frame(as.table(mat))
  names(df) <- c("Seq1", "Seq2", "Score")
  df
})

# Step 5: Downsample large matrices to avoid rendering errors
score_matrices_small <- lapply(score_matrices, function(df) {
  df[sample(nrow(df), min(500, nrow(df))), ]  # keep up to 500 random points
})

# Step 6: Generate tile plots for each alignment
plots <- lapply(score_matrices_small, function(df) {
  ggplot(df, aes(x = Seq1, y = Seq2, fill = Score)) +
    geom_tile() +
    scale_fill_gradient(low = "white", high = "blue") +
    theme_minimal()
})

# Step 7: Arrange plots in batches to prevent timeout
batch1 <- plots[1:6]
batch2 <- plots[7:12]
batch3 <- plots[13:15]

grid.arrange(grobs = batch1, ncol = 3)
grid.arrange(grobs = batch2, ncol = 3)
grid.arrange(grobs = batch3, ncol = 3)

# Step 8: Save each plot as a PNG file
for (i in seq_along(plots)) {
  ggsave(filename = paste0("ND_alignment_", i, ".png"),
         plot = plots[[i]], width = 6, height = 5, dpi = 150)
}
